/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package backend_models;

import java.awt.*;
import java.awt.image.BufferedImage;

/**
 *
 * @author Dugle_000
 */
public class Pixel {
    public int x, y;
    Pixel(int x, int y){
        this.x = x;
        this.y = y;
    }
    
}
